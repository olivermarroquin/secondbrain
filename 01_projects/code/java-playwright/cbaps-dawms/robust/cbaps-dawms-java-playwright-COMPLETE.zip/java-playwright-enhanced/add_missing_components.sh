#!/bin/bash

# Add CBAPS Missing Pages
cat > src/main/java/com/playwright/cbaps/pages/PortalHomePage.java << 'EOFPORTAL'
package com.playwright.cbaps.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;
import org.slf4j.*;

public class PortalHomePage {
    private static final Logger log = LoggerFactory.getLogger(PortalHomePage.class);
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator cbapsLink, dawmsLink;
    
    public PortalHomePage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.cbapsLink = page.locator("a:has-text('CBAPS')");
        this.dawmsLink = page.locator("a:has-text('DAWMS')");
    }
    
    public CBAPSDashboardPage openCBAPS() {
        pwm.clickElement(cbapsLink);
        return new CBAPSDashboardPage(page, pwm);
    }
    
    public com.playwright.dawms.pages.DAWMSDashboardPage openDAWMS() {
        pwm.clickElement(dawmsLink);
        return new com.playwright.dawms.pages.DAWMSDashboardPage(page, pwm);
    }
}
EOFPORTAL

cat > src/main/java/com/playwright/cbaps/pages/CBAPSDashboardPage.java << 'EOFDASH'
package com.playwright.cbaps.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;
import org.slf4j.*;

public class CBAPSDashboardPage {
    private static final Logger log = LoggerFactory.getLogger(CBAPSDashboardPage.class);
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator createRequisitionBtn;
    
    public CBAPSDashboardPage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.createRequisitionBtn = page.locator("button:has-text('Create Requisition')");
        pwm.waitUntilElementVisible("button:has-text('Create Requisition')");
    }
    
    public RequisitionPage goToCreateRequisition() {
        pwm.clickElement(createRequisitionBtn);
        return new RequisitionPage(page, pwm);
    }
}
EOFDASH

# Add ALL DAWMS Components
mkdir -p src/main/java/com/playwright/dawms/{pages,models,tests,api}

# DAWMS Models
cat > src/main/java/com/playwright/dawms/models/SubmissionData.java << 'EOFSUB'
package com.playwright.dawms.models;
public class SubmissionData {
    private String submissionType, applicationNumber, sponsorName, drugName;
    public SubmissionData(String type, String appNum) { this.submissionType = type; this.applicationNumber = appNum; }
    public SubmissionData(String type, String appNum, String sponsor, String drug) {
        this(type, appNum); this.sponsorName = sponsor; this.drugName = drug;
    }
    public String getSubmissionType() { return submissionType; }
    public String getApplicationNumber() { return applicationNumber; }
    public String getSponsorName() { return sponsorName; }
    public String getDrugName() { return drugName; }
}
EOFSUB

cat > src/main/java/com/playwright/dawms/models/ReviewerData.java << 'EOFREV'
package com.playwright.dawms.models;
public class ReviewerData {
    private String name, role, specialty;
    public ReviewerData(String name, String role) { this.name = name; this.role = role; }
    public ReviewerData(String name, String role, String specialty) { this(name, role); this.specialty = specialty; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public String getSpecialty() { return specialty; }
}
EOFREV

# DAWMS Pages (all 6)
cat > src/main/java/com/playwright/dawms/pages/DAWMSDashboardPage.java << 'EOFDAWMSDASH'
package com.playwright.dawms.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;
import org.slf4j.*;

public class DAWMSDashboardPage {
    private static final Logger log = LoggerFactory.getLogger(DAWMSDashboardPage.class);
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator submissionIntakeBtn;
    
    public DAWMSDashboardPage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.submissionIntakeBtn = page.locator("button:has-text('Submission Intake')");
        pwm.waitUntilElementVisible("button:has-text('Submission Intake')");
    }
    
    public SubmissionIntakePage goToSubmissionIntake() {
        pwm.clickElement(submissionIntakeBtn);
        return new SubmissionIntakePage(page, pwm);
    }
}
EOFDAWMSDASH

cat > src/main/java/com/playwright/dawms/pages/SubmissionIntakePage.java << 'EOFINTAKE'
package com.playwright.dawms.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;
import com.playwright.dawms.models.SubmissionData;
import org.slf4j.*;

public class SubmissionIntakePage {
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator submissionTypeDropdown, applicationNumberInput, createSubmissionButton;
    
    public SubmissionIntakePage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.submissionTypeDropdown = page.locator("#submissionType");
        this.applicationNumberInput = page.locator("#applicationNumber");
        this.createSubmissionButton = page.locator("button:has-text('Create Submission')");
        pwm.waitUntilElementVisible("#submissionType");
    }
    
    public ReviewerAssignmentPage createSubmission(SubmissionData data) {
        pwm.selectDropdown(submissionTypeDropdown, data.getSubmissionType());
        pwm.enterText(applicationNumberInput, data.getApplicationNumber());
        pwm.clickElement(createSubmissionButton);
        return new ReviewerAssignmentPage(page, pwm);
    }
}
EOFINTAKE

cat > src/main/java/com/playwright/dawms/pages/ReviewerAssignmentPage.java << 'EOFREVIEWER'
package com.playwright.dawms.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;
import com.playwright.dawms.models.ReviewerData;
import org.slf4j.*;
import java.util.List;

public class ReviewerAssignmentPage {
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator reviewerRoleDropdown, reviewerNameInput, assignReviewerButton, continueButton;
    
    public ReviewerAssignmentPage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.reviewerRoleDropdown = page.locator("#reviewerRole");
        this.reviewerNameInput = page.locator("#reviewerName");
        this.assignReviewerButton = page.locator("button:has-text('Assign')");
        this.continueButton = page.locator("button:has-text('Route to Signature')");
        pwm.waitUntilElementVisible("#reviewerRole");
    }
    
    public ReviewerAssignmentPage assignReviewer(ReviewerData data) {
        pwm.selectDropdown(reviewerRoleDropdown, data.getRole());
        pwm.enterText(reviewerNameInput, data.getName());
        pwm.clickElement(assignReviewerButton);
        return this;
    }
    
    public void assignMultipleReviewers(List<ReviewerData> reviewers) {
        for (ReviewerData r : reviewers) assignReviewer(r);
    }
    
    public SignatureRoutingPage routeToSignatureStep() {
        pwm.clickElement(continueButton);
        return new SignatureRoutingPage(page, pwm);
    }
}
EOFREVIEWER

cat > src/main/java/com/playwright/dawms/pages/SignatureRoutingPage.java << 'EOFSIG'
package com.playwright.dawms.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;

public class SignatureRoutingPage {
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator signerDropdown, submitButton;
    
    public SignatureRoutingPage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.signerDropdown = page.locator("#signer");
        this.submitButton = page.locator("button:has-text('Submit for Signature')");
        pwm.waitUntilElementVisible("#signer");
    }
    
    public MilestoneStatusPage submitForSignature(String signer) {
        pwm.selectDropdown(signerDropdown, signer);
        pwm.clickElement(submitButton);
        return new MilestoneStatusPage(page, pwm);
    }
}
EOFSIG

cat > src/main/java/com/playwright/dawms/pages/MilestoneStatusPage.java << 'EOFMILE'
package com.playwright.dawms.pages;
import com.microsoft.playwright.*;
import com.playwright.cbaps.library.EnhancedPlaywrightManager;

public class MilestoneStatusPage {
    private Page page;
    private EnhancedPlaywrightManager pwm;
    private Locator milestoneLabel, statusLabel;
    
    public MilestoneStatusPage(Page page, EnhancedPlaywrightManager pwm) {
        this.page = page; this.pwm = pwm;
        this.milestoneLabel = page.locator("#milestone");
        this.statusLabel = page.locator("#status");
        pwm.waitUntilElementVisible("#status");
    }
    
    public String getMilestone() { return pwm.getText(milestoneLabel); }
    public String getStatus() { return pwm.getText(statusLabel); }
    public boolean validateStatus(String expected) { return getStatus().equals(expected); }
    public boolean validateMilestone(String expected) { return getMilestone().equals(expected); }
}
EOFMILE

# DAWMS Tests
cat > src/main/java/com/playwright/dawms/tests/DAWMSEndToEndTests.java << 'EOFDAWMSTEST'
package com.playwright.dawms.tests;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.playwright.cbaps.library.Base;
import com.playwright.dawms.models.*;
import com.playwright.dawms.pages.*;
import com.playwright.cbaps.pages.PortalHomePage;
import java.util.Arrays;

public class DAWMSEndToEndTests extends Base {
    private static final String PORTAL_URL = "https://dawms-portal.example.com";
    
    @Test
    public void completeSubmissionWorkflowTest() {
        pwm.navigateTo(PORTAL_URL);
        PortalHomePage portal = new PortalHomePage(page, pwm);
        DAWMSDashboardPage dashboard = portal.openDAWMS();
        
        SubmissionData subData = new SubmissionData("NDA", "APP-" + System.currentTimeMillis(), "PharmaCorp", "DrugX");
        SubmissionIntakePage intakePage = dashboard.goToSubmissionIntake();
        ReviewerAssignmentPage reviewerPage = intakePage.createSubmission(subData);
        
        reviewerPage.assignMultipleReviewers(Arrays.asList(
            new ReviewerData("Dr. Smith", "Clinical Reviewer"),
            new ReviewerData("Dr. Johnson", "Statistical Reviewer")
        ));
        
        SignatureRoutingPage signaturePage = reviewerPage.routeToSignatureStep();
        MilestoneStatusPage statusPage = signaturePage.submitForSignature("Division Director");
        
        Assert.assertTrue(statusPage.validateStatus("Pending Signature"));
    }
}
EOFDAWMSTEST

# DAWMS API
cat > src/main/java/com/playwright/dawms/api/APIHelper.java << 'EOFDAWMSAPI'
package com.playwright.dawms.api;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;

public class APIHelper {
    private static final String BASE_URL = "https://api.dawms.example.com";
    static { RestAssured.baseURI = BASE_URL; }
    
    public static Response get(String endpoint) {
        return given().contentType(ContentType.JSON).when().get(endpoint).then().extract().response();
    }
    
    public static Response post(String endpoint, Object body) {
        return given().contentType(ContentType.JSON).body(body).when().post(endpoint).then().extract().response();
    }
}
EOFDAWMSAPI

cat > src/main/java/com/playwright/dawms/api/DAWMS_APITests.java << 'EOFDAWMSAPITEST'
package com.playwright.dawms.api;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.response.Response;

public class DAWMS_APITests {
    @Test
    public void testGetSubmissions() {
        Response response = APIHelper.get("/submissions");
        Assert.assertEquals(response.getStatusCode(), 200);
    }
}
EOFDAWMSAPITEST

echo "✅ All missing components added!"
find src -name "*.java" | wc -l
