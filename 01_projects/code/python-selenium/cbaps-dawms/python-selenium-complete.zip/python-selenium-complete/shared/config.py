CBAPS_URL = "https://cbaps.example.com"
DAWMS_URL = "https://dawms.example.com"
CBAPS_API = "https://api.cbaps.example.com"
DAWMS_API = "https://api.dawms.example.com"
