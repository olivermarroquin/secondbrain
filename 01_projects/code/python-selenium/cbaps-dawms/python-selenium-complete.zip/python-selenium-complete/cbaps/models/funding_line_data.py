from dataclasses import dataclass

@dataclass
class FundingLineData:
    amount: str
    fiscal_year: str
